from dash import html
from navbar import create_navbar

nav = create_navbar()

header = html.H3('Assignment 2 American Football')
body = html.P('Use the links bellow to see our anwsers to the assignment')
opg3A = html.A("3A game results", href='/page-2') 
opg3B = html.A("3B all time NFL rank", href='/page-3')

menu = html.Div(children=
                [html.Ul(
                        children=[
                            html.Li(children=[opg3A]),
                            html.Li(children=[opg3B]) 
                            ]) 
                ])
                


def create_page_home():
    layout = html.Div([
        nav,
        header,
        body,
        menu
    ])
    return layout