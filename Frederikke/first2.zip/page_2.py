from dash import Dash, dash_table,html
from navbar import create_navbar
import dash_bootstrap_components as dbc
import pandas as pd


nfl_data = "C:/Users/frede/OneDrive/Dokumenter/Python Scripts/AmFoot/players_allInone.csv"
df = pd.read_csv(nfl_data, index_col=0)

# Combining the columns PtsW and PtsL, and rearranging them in ascending order and countning the occurence of the same results
# creatining af new variable, 
nfl_new= df.groupby(['PtsW','PtsL']).size().reset_index(name="Count")

# rearring to descending order 
nf2 = nfl_new.sort_index(ascending= False)

app = Dash(external_stylesheets=[dbc.themes.SOLAR])#ikke sikker på den her linje gør noget længere

nav = create_navbar()
header = html.H3('count the numbers of different results and display them in a decreasingly ordered list')
body = html.Div(
        [ #main div container

            #first child div container (left column)
            html.Div(className='table table-responsive-md p-3', 
                    children=[html.H3('Table showing all game results in decending order, and counting how many times a result has occured.'),
                        dash_table.DataTable(columns=[{'name': 'Winning Team', 'id': 'PtsW'}, {'name': 'Losing Team', 'id': 'PtsL'}, {'name': 'Count', 'id': 'Count'}],
                        # dash_table.DataTable(columns=[{'name': col, 'id': nf2_columns[idx]} for (idx, col) in enumerate(display_columns)],
                        data=nf2.to_dict('records'), 
                        page_size=50, 
                        filter_action="none",
                        sort_action="native",
                        sort_mode="single",
                        column_selectable="single",
                        style_table={"fontFamily": 'Roboto'},
                                    
                        style_header={
                            'backgroundColor': 'white',
                            'fontWeight': 'bold',
                            'padding':'0.75rem'
                        },
                        style_cell={
                            "fontFamily": 'Roboto',
                            'fontWeight': '400',
                            'lineHeight': '1.5',
                            'color': '#212529',
                            'textAlign': 'left',
                            'whiteSpace': 'normal',
                            'height': 'auto',
                            'padding':'0.75rem',
                            'border': '1px solid #dee2e6',
                            'verticalAlign': 'top',
                            
                        },
                        style_data_conditional=[
                         {
                             'if': {'row_index': 'odd'},
                             'backgroundColor': '#f8f9fa'
                         }],
                                          
                        )
                    ], style={'padding': 10, 'width': '50%'})
                
            #end of main div
        ])


def create_page_2():
    layout = html.Div([
        nav,
        header,
        body
    ])
    return layout