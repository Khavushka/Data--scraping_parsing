from dash import html
from navbar import create_navbar

import dash_bootstrap_components as dbc
import pandas as pd
from navbar import create_navbar
from dash import Dash, dash_table, html


#Load the 
# data = pd.read_csv("team_easyon.csv")
url = 'https://raw.githubusercontent.com/Khavushka/Project-2-American-Football1.DataGathering-ScrapeallfootballresultsoftheNationalFootballLeague-NFL-/main/team_easyon.csv'
dff = pd.read_csv(url,usecols=['Teams', 'Wins','Losses', 'Ties'])


#Sorts a data frame in Ascending or Descending order of passed Column
df = dff.sort_values(by=['Wins','Ties'], ascending=False)

#ype-cast both the columns of interest to str and combine them by concatenating them.
#Convert these back to numerical values so that they could be differentiated based on their magnitude.

col1 = df["Wins"].astype(str) 
col2 = df["Ties"].astype(str)


df['Rank'] = (col1+col2).astype(int).rank(method='dense', ascending=False).astype(int)

df.sort_values('Rank')

app = Dash(external_stylesheets=[dbc.themes.SOLAR])

#Display part
nav = create_navbar()

header = html.H3('3B all time NFL rank')
body = html.Div([
    #first child div container (left column)
    html.Div(className='table table-responsive-md p-3', 
            children=[html.H3('All Time NFL Table, showing all wins, losses, ties, and rank for each franchies since 1970-2021.'),
                dash_table.DataTable(columns=[{'name': 'Franchies', 'id': 'Teams'}, {'name': 'Wins', 'id': 'Wins'}, {'name': 'Losses', 'id': 'Losses'},{'name': 'Ties', 'id': 'Ties'},{'name': 'Rank', 'id': 'Rank'}],
                # dash_table.DataTable(columns=[{'name': col, 'id': nf2_columns[idx]} for (idx, col) in enumerate(display_columns)],
                data=df.to_dict('records'), 
                page_size=50, 
                filter_action="none",
                sort_action="native",#sorts by column
                sort_mode="single",
                column_selectable="single",# you can only choose one column at a time
                style_table={"fontFamily": 'Roboto'},
                            
                style_header={
                    'backgroundColor': 'white',
                    'fontWeight': 'bold',
                    'padding':'0.75rem'
                },
                style_cell={
                    "fontFamily": 'Roboto',
                    'fontWeight': '400',
                    'lineHeight': '1.5',
                    'color': '#212529',
                    'textAlign': 'left',
                    'whiteSpace': 'normal',
                    'height': 'auto',
                    'padding':'0.75rem',
                    'border': '1px solid #dee2e6',
                    'verticalAlign': 'top',
                    
                },
                style_data_conditional=[
                 {
                     'if': {'row_index': 'odd'},
                     'backgroundColor': '#f8f9fa'
                 }],
                                  
                )
            ], style={'padding': 10, 'width': '50%'})
        
    #end of main div
])


def create_page_3():
    layout = html.Div([
        nav,
        header,
        body
    ])
    return layout